BOT_TOKEN = 'PASTE_YOUR_BOT_TOKEN_HERE'
ADMIN_ID = 123456789  # Replace with your Telegram user ID
